# NYC Airbnb 2019 Analysis Project

## 🏠 Overview

This project provides a comprehensive, end-to-end analysis of Airbnb listings in New York City using 2019 data. It demonstrates a complete data science workflow from raw data processing to interactive dashboard deployment, delivering actionable insights for hosts, investors, and market analysts.

**Key Achievements:**
- 📊 Analyzed 48,895 NYC Airbnb listings across all 5 boroughs
- 🤖 Built predictive models with 58.4% accuracy (R² = 0.584)
- 🎯 Identified 5 distinct market segments through clustering
- 📱 Created interactive dashboard for real-time market analysis
- 📈 Generated actionable business recommendations

## 🏗️ Project Structure

```
├── README.md                          # Project documentation
├── requirements.txt                   # Python dependencies
├── app.py                            # Streamlit dashboard application
├── presentation_slide_notes.md       # Presentation materials
├── data/
│   └── AB_NYC_2019.csv              # Original dataset (48,895 listings)
├── notebooks/
│   └── airbnb_analysis.ipynb        # Complete analysis notebook
├── src/                             # Modular Python package
│   ├── data_prep.py                 # Data cleaning & preprocessing
│   ├── eda.py                       # Exploratory data analysis
│   └── model.py                     # Machine learning pipeline
└── outputs/                         # Generated artifacts
    ├── figures/                     # 9 publication-ready visualizations
    │   ├── listings_by_borough.png
    │   ├── price_distribution.png
    │   ├── price_by_room_type.png
    │   ├── top_neighborhoods.png
    │   ├── price_vs_reviews.png
    │   ├── correlation_heatmap.png
    │   ├── feature_importance.png
    │   ├── model_performance.png
    │   └── kmeans_clusters.png
    ├── cleaned_airbnb.csv            # Clean dataset (45,912 listings)
    ├── summary_by_borough.csv        # Borough-level statistics
    ├── model_price_rf.joblib         # Trained Random Forest model
    ├── model_price_lr.joblib         # Baseline Linear Regression
    └── report_summary.md             # Executive summary report
```

## 🚀 Quick Start

### Prerequisites
- Python 3.8+ 
- pip package manager

### Installation

1. **Clone or download the project**
   ```bash
   # If using git
   git clone <repository-url>
   cd airbnb-nyc-analysis
   ```

2. **Create virtual environment**
   ```bash
   # Windows
   python -m venv venv
   venv\Scripts\activate
   
   # macOS/Linux
   python3 -m venv venv
   source venv/bin/activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

### Running the Analysis

**Option 1: Interactive Dashboard (Recommended)**
```bash
streamlit run app.py
```
Opens interactive dashboard at `http://localhost:8501`

**Option 2: Jupyter Notebook**
```bash
jupyter notebook notebooks/airbnb_analysis.ipynb
```
Complete step-by-step analysis with explanations

**Option 3: Modular Scripts**
```python
# Data cleaning pipeline
from src.data_prep import run_data_cleaning_pipeline
df_clean = run_data_cleaning_pipeline('data/AB_NYC_2019.csv', 'outputs/cleaned_data.csv')

# EDA pipeline
from src.eda import run_eda_pipeline
run_eda_pipeline(df_clean)

# Modeling pipeline
from src.model import run_modeling_pipeline
results = run_modeling_pipeline(df_clean)
```

## 📊 Key Findings & Insights

### Market Overview
- **Total Listings**: 45,912 (after cleaning)
- **Average Price**: $120/night
- **Price Range**: $10 - $334/night
- **Market Concentration**: Manhattan (42.5%) + Brooklyn (42.3%) = 85%

### Geographic Insights
| Borough | Listings | Avg Price | Market Share |
|---------|----------|-----------|--------------|
| Manhattan | 19,505 | $146 | 42.5% |
| Brooklyn | 19,406 | $106 | 42.3% |
| Queens | 5,567 | $89 | 12.1% |
| Bronx | 1,069 | $77 | 2.3% |
| Staten Island | 365 | $89 | 0.8% |

### Room Type Analysis
- **Entire home/apt**: $130 avg (51.8% of market) - Premium segment
- **Private room**: $76 avg (45.8% of market) - Value segment  
- **Shared room**: $50 avg (2.4% of market) - Budget segment

### Predictive Model Performance
- **Random Forest**: R² = 0.584, MAE = $31 (Best performer)
- **Linear Regression**: R² = 0.479, MAE = $36 (Baseline)
- **Top Predictors**: Geographic location, room type, borough, host productivity

### Market Segmentation (5 Clusters)
1. **Mainstream** (64%): Mid-range properties, balanced characteristics
2. **Budget** (27%): Lower prices, higher availability
3. **High-Volume** (8%): Active listings with many reviews
4. **Premium** (1%): Exclusive high-end properties
5. **Niche** (0.1%): Specialized unique offerings

## 💡 Business Recommendations

### For Hosts
- **Location Strategy**: Focus on Manhattan/Brooklyn for premium pricing
- **Room Type**: Entire homes command 40%+ premium over private rooms
- **Pricing**: Use ML model for competitive pricing (±$31 accuracy)
- **Availability**: Balance availability with demand optimization

### For Investors
- **Growth Markets**: Queens & Bronx offer expansion opportunities
- **Portfolio Mix**: Combine entire homes (premium) + private rooms (volume)
- **Geographic Spread**: Diversify across multiple boroughs
- **Host Strategy**: Consider multi-listing approach in Manhattan

### For Guests
- **Value Options**: Brooklyn offers best value for entire homes
- **Budget Travel**: Private rooms 40%+ cheaper than entire homes
- **Alternatives**: Queens provides affordable Manhattan alternatives
- **Timing**: Higher availability in Bronx/Staten Island

## 🛠️ Technical Details

### Data Processing Pipeline
1. **Data Loading**: 48,895 original listings
2. **Cleaning**: Removed 6.1% outliers, handled missing values
3. **Feature Engineering**: Created 5 new predictive features
4. **Validation**: Comprehensive quality checks and sanity tests

### Machine Learning Pipeline
- **Feature Preparation**: 16 features (numeric + one-hot encoded)
- **Model Training**: Random Forest + Linear Regression
- **Evaluation**: Train/test split (80/20) with cross-validation
- **Clustering**: K-means with 5 clusters on scaled features

### Code Quality
- **Modular Design**: Separate modules for data prep, EDA, modeling
- **Documentation**: Comprehensive docstrings and type hints
- **Testing**: Built-in validation and sanity checks
- **Reproducibility**: Fixed random seeds and version control

## 📱 Interactive Dashboard Features

The Streamlit dashboard (`app.py`) provides:

- **🔍 Interactive Filters**: Borough, room type, price range
- **🗺️ Geographic Maps**: Price and review overlays
- **📊 Real-time Analytics**: Dynamic statistics and comparisons  
- **🤖 Price Prediction**: ML-powered pricing tool
- **📈 Market Analysis**: Trends and pattern visualization

## 📋 Dependencies

Core packages (see `requirements.txt` for versions):
- **Data Processing**: pandas, numpy
- **Visualization**: matplotlib, seaborn, plotly, folium
- **Machine Learning**: scikit-learn, joblib
- **Dashboard**: streamlit
- **Notebook**: jupyter

## 🔬 Model Limitations & Considerations

### Limitations
- **Temporal Scope**: Based on 2019 data only
- **Qualitative Factors**: Cannot capture listing quality/photos
- **External Variables**: No local events or transportation data
- **Platform Specific**: Airbnb-only data

### Bias Considerations
- **Geographic Bias**: May favor well-represented neighborhoods
- **Price Range Bias**: Performance varies across price segments
- **Temporal Bias**: 2019 patterns may not reflect current market

### Recommendations for Use
- Use predictions as baseline estimates, not absolute values
- Consider local market knowledge and seasonal factors
- Regularly retrain models with fresh data
- Validate against current market conditions

## 🚀 Future Enhancements

### Immediate Opportunities
- **Time Series Analysis**: Seasonal patterns and booking trends
- **NLP Analysis**: Review sentiment and listing optimization
- **Real-time Data**: Live market monitoring and alerts
- **Multi-platform**: Expand beyond Airbnb (VRBO, etc.)

### Advanced Features
- **Dynamic Pricing**: Automated pricing optimization
- **Demand Forecasting**: Predictive booking models
- **Competitive Intelligence**: Market positioning analysis
- **ROI Calculator**: Investment return optimization

## 📞 Support & Contact

For questions, issues, or contributions:
- Review the Jupyter notebook for detailed explanations
- Check the `outputs/report_summary.md` for business insights
- Examine the modular code in `src/` for technical details
- Use the interactive dashboard for exploratory analysis

## 📄 License

This project is for educational and analytical purposes. Dataset sourced from public Airbnb data.

---

**🎯 Ready for production deployment and stakeholder presentation!**